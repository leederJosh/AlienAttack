<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="GoodLuckSign" tilewidth="300" tileheight="81" tilecount="8" columns="1">
 <image source="GoodLuckSign.png" width="300" height="648"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="150"/>
   <frame tileid="1" duration="150"/>
   <frame tileid="2" duration="150"/>
   <frame tileid="3" duration="150"/>
   <frame tileid="4" duration="150"/>
   <frame tileid="5" duration="150"/>
   <frame tileid="6" duration="150"/>
   <frame tileid="7" duration="150"/>
   <frame tileid="7" duration="150"/>
   <frame tileid="6" duration="150"/>
   <frame tileid="5" duration="150"/>
   <frame tileid="4" duration="150"/>
   <frame tileid="3" duration="150"/>
   <frame tileid="2" duration="150"/>
   <frame tileid="1" duration="150"/>
   <frame tileid="0" duration="150"/>
  </animation>
 </tile>
</tileset>
