<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="Floor" tilewidth="16" tileheight="16" tilecount="140" columns="10">
 <image source="Floor.png" width="162" height="224"/>
</tileset>
