<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="RainAnimation" tilewidth="600" tileheight="414" tilecount="5" columns="5">
 <image source="Rain.png" width="3200" height="414"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="200"/>
   <frame tileid="1" duration="200"/>
   <frame tileid="2" duration="200"/>
  </animation>
 </tile>
</tileset>
