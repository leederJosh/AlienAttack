<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="AnimatedWindows" tilewidth="32" tileheight="32" tilecount="5" columns="1">
 <image source="AnimatedWindows.png" width="32" height="160"/>
 <tile id="0">
  <animation>
   <frame tileid="4" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="1" duration="300"/>
   <frame tileid="0" duration="300"/>
   <frame tileid="0" duration="300"/>
   <frame tileid="0" duration="300"/>
   <frame tileid="1" duration="300"/>
   <frame tileid="1" duration="300"/>
   <frame tileid="1" duration="300"/>
   <frame tileid="1" duration="300"/>
   <frame tileid="2" duration="300"/>
   <frame tileid="2" duration="300"/>
   <frame tileid="2" duration="300"/>
   <frame tileid="2" duration="300"/>
   <frame tileid="2" duration="300"/>
   <frame tileid="3" duration="300"/>
   <frame tileid="3" duration="300"/>
   <frame tileid="3" duration="111"/>
   <frame tileid="3" duration="300"/>
   <frame tileid="3" duration="111"/>
   <frame tileid="3" duration="111"/>
   <frame tileid="3" duration="300"/>
   <frame tileid="4" duration="90"/>
   <frame tileid="4" duration="90"/>
  </animation>
 </tile>
</tileset>
