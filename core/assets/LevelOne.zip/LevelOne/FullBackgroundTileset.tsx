<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="FullBackgroundTileset" tilewidth="16" tileheight="16" tilecount="12750" columns="150">
 <image source="FullBackgroundTileset.png" width="2400" height="1360"/>
</tileset>
