<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="Buildings" tilewidth="16" tileheight="16" tilecount="4" columns="2">
 <image source="BrickTileset.png" width="32" height="32"/>
</tileset>
